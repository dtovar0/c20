/**
 * Returns optimal pageLength based on viewport height.
 *   < 900px → 9 rows   >= 900px → 10 rows
 */
function getPageLength() {
    const h = window.innerHeight;
    if (h < 900) return 9;
    return 10;
}

/**
 * MODULE: Centralized Nexus Table Engine (DataTables Powered)
 * Logic for rendering Audit tables with DataTables integration.
 */

let auditDataTable;

/**
 * INITIALIZATION
 */
$(document).ready(function() {
    initAuditDataTable();

    // Universal Search Integration
    $('#auditSearch').on('input', function() {
        if (auditDataTable) {
            auditDataTable.search(this.value).draw();
        }
    });

    // Refresh Action
    $('#refreshAudit').on('click', function() {
        if (auditDataTable) {
            auditDataTable.ajax.reload();
        }
    });
});

/**
 * Initializes DataTables for Audit
 */
function initAuditDataTable() {
    const tableEl = $('table');
    if (!tableEl.length) return;

    auditDataTable = tableEl.DataTable({
        ajax: {
            url: '/audit/api/list',
            dataSrc: 'logs'
        },
        columns: [
            { data: 'id', width: '80px', render: (data) => `<div class="flex items-center h-full text-primary/60 font-black">#${String(data).padStart(5, '0')}</div>` },
            { data: 'user', width: '130px', render: (data) => `<div class="flex items-center h-full font-bold text-label/80 truncate">${data || 'SYSTEM'}</div>` },
            { 
                data: 'action', 
                width: '170px',
                render: (data) => {
                    const actionColors = {
                        'tarea creada': 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
                        'tarea terminada': 'bg-violet-500/10 text-violet-400 border-violet-500/20',
                        'tarea iniciada': 'bg-primary/10 text-primary border-primary/20',
                        'LOGIN': 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20',
                        'LOGOUT': 'bg-slate-500/10 text-slate-400 border-slate-500/20',
                        'SET_IDENTITY': 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                    };
                    const actionClass = actionColors[data] || 'bg-primary/5 text-primary/70 border-primary/20';
                    return `<div class="flex items-center h-full"><div class="inline-flex px-3 py-1 text-[12px] font-black tracking-widest uppercase border rounded-lg ${actionClass} truncate">${data}</div></div>`;
                }
            },
            { 
                data: 'status', 
                width: '100px',
                render: (data) => {
                    const statusColors = {
                        'success': 'text-emerald-400',
                        'error': 'text-rose-400',
                        'warning': 'text-amber-400',
                        'info': 'text-primary'
                    };
                    const colorClass = statusColors[data.toLowerCase()] || statusColors['info'];
                    return `<div class="flex items-center justify-center h-full"><span class="text-[12px] font-black tracking-widest uppercase ${colorClass}">${data}</span></div>`;
                }
            },
            { data: 'detail', width: 'auto', render: (data) => `<div class="flex items-center h-full text-[12px] font-bold text-label/60 line-clamp-1 min-w-0 overflow-hidden text-ellipsis" title="${data || ''}">${data || '-'}</div>` },
            { data: 'time', width: '180px', render: (data) => `<div class="flex items-center h-full font-mono text-[12px] font-bold text-label/60 justify-end">${data}</div>` }
        ],
        autoWidth: false,
        pageLength: getPageLength(),
        pagingType: 'simple',
        order: [[0, 'desc']],
        layout: {
            topStart: null,
            topEnd: null,
            bottomStart: 'info',
            bottomEnd: 'paging'
        },
        language: {
            zeroRecords: "No se encontraron registros",
            info: "Mostrando _START_-_END_ de _TOTAL_ registros",
            infoEmpty: "Mostrando 0-0 de 0 registros",
            infoFiltered: "(filtrado de _MAX_ registros totales)",
            paginate: {
                previous: '<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path></svg>',
                next: '<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>'
            }
        },
        drawCallback: function(settings) {
            renderGhostRows(settings, 6);
        },
        initComplete: function() {
            const cell = $(this.api().table().container()).find('.dt-layout-row.dt-layout-table .dt-layout-cell');
            const tbl  = cell.children('table');
            if (tbl.length && !cell.children('.nx-table-scroll').length) {
                tbl.wrap('<div class="nx-table-scroll"></div>');
            }
            const api = this.api();
            let resizeTimer;
            $(window).on('resize.dtPageLen', function() {
                clearTimeout(resizeTimer);
                resizeTimer = setTimeout(function() {
                    const newLen = getPageLength();
                    if (api.page.len() !== newLen) api.page.len(newLen).draw();
                    else api.draw(false);
                }, 200);
            });
        }
    });

    // Register globally for top bar search
    window.activeNexusTable = auditDataTable;
}

/**
 * Sizes all rows equally to fill the table wrapper, then adds ghost rows.
 * rowH = floor( (wrapperHeight - borderGaps) / (pageLen + 1) )
 */
function renderGhostRows(settings, columns) {
    const api     = new $.fn.dataTable.Api(settings);
    const info    = api.page.info();
    const tbody   = $(settings.nTBody);
    const pageLen = api.page.len();

    // 1. Cleanup
    tbody.find('.ghost-row').remove();
    tbody.find('.dataTables_empty').closest('tr').remove();

    // 2. Calculate row height using the wrapper's offsetHeight
    const container  = api.table().container();
    const scrollWrap = $(container).find('.nx-table-scroll');
    let rowH = 52;
    if (scrollWrap.length && scrollWrap[0].offsetHeight > 0) {
        const totalRows = pageLen + 1; // +1 for thead
        const gapTotal  = (totalRows - 1) * 4; // border-spacing-y: 4px per gap
        const usableH   = scrollWrap[0].offsetHeight - gapTotal;
        if (usableH > 0) rowH = Math.max(40, Math.floor(usableH / totalRows));
    }

    // 3. Apply rowH to thead
    const thead = $(api.table().header());
    thead.find('tr').css('height', rowH + 'px');
    thead.find('th').css('height', rowH + 'px');

    // 4. Apply rowH to real tbody rows
    tbody.find('tr:not(.ghost-row)').css('height', rowH + 'px');
    tbody.find('tr:not(.ghost-row) td').css('height', rowH + 'px');

    // 5. Ghost rows to fill remaining slots
    const realRows   = info.end - info.start;
    const ghostCount = pageLen - realRows;
    if (ghostCount <= 0) return;

    let ghostHtml = '';
    for (let i = 0; i < ghostCount; i++) {
        ghostHtml += `
            <tr class="ghost-row pointer-events-none select-none" style="opacity:0.25;height:${rowH}px;">
                <td style="height:${rowH}px;background:rgb(var(--color-surface-container-bg)/0.08);border-top:1px solid rgb(var(--color-panel-border)/0.15);border-bottom:1px solid rgb(var(--color-panel-border)/0.15);border-left:1px solid rgb(var(--color-panel-border)/0.15);border-radius:1rem 0 0 1rem;padding:0 1.25rem;">
                    <div style="height:6px;width:40px;background:rgb(var(--color-label)/0.08);border-radius:999px;margin:auto;"></div>
                </td>
                ${Array(columns - 2).fill(0).map(() => `
                    <td style="height:${rowH}px;background:rgb(var(--color-surface-container-bg)/0.08);border-top:1px solid rgb(var(--color-panel-border)/0.15);border-bottom:1px solid rgb(var(--color-panel-border)/0.15);padding:0 1.25rem;">
                        <div style="height:4px;width:60%;background:rgb(var(--color-label)/0.05);border-radius:999px;"></div>
                    </td>
                `).join('')}
                <td style="height:${rowH}px;background:rgb(var(--color-surface-container-bg)/0.08);border-top:1px solid rgb(var(--color-panel-border)/0.15);border-bottom:1px solid rgb(var(--color-panel-border)/0.15);border-right:1px solid rgb(var(--color-panel-border)/0.15);border-radius:0 1rem 1rem 0;padding:0 1.25rem;">
                    <div style="height:4px;width:40%;background:rgb(var(--color-label)/0.05);border-radius:999px;"></div>
                </td>
            </tr>`;
    }
    tbody.append(ghostHtml);
}


// Adaptive Redraw on Resize
$(window).on('resize', () => {
    if (auditDataTable) auditDataTable.draw(false);
});
